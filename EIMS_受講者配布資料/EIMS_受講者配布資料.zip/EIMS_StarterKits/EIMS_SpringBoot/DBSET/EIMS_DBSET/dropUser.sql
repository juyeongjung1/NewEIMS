-- ユーザの削除

-- ユーザ名：eimsuser
-- パスワード：Pa$$w0rd

USE mysql;
DROP USER IF EXISTS 'eimsuser'@'localhost';
quit
