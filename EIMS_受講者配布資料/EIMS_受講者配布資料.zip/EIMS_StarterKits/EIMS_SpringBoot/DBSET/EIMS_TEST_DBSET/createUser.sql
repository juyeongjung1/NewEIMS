-- ユーザの作成

-- ユーザ名：eimsuser_test
-- パスワード：eimspass


CREATE USER IF NOT EXISTS 'eimsuser_test'@'localhost' IDENTIFIED BY 'eimspass';
GRANT all ON eimsdb_test.* TO 'eimsuser_test'@'localhost';
FLUSH PRIVILEGES;



quit
