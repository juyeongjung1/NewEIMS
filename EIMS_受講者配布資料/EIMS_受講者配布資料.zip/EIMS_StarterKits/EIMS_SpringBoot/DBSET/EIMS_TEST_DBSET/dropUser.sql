-- ユーザの削除

-- ユーザ名：eimsuser_test
-- パスワード：eimspass

USE mysql;
DROP USER IF EXISTS 'eimsuser_test'@'localhost';
quit
