package jp.co.trainocate.eims.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EmployeeController {

    /** トップページを表示する */
    @GetMapping({ "/", "/index" })
    public String index() {
        return "index";
    }
}
