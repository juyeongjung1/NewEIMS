package jp.co.trainocate.eims.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.trainocate.eims.entity.Employee;
import jp.co.trainocate.eims.form.EmployeeForm;
import jp.co.trainocate.eims.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;

    /** {@inheritDoc} */
    @Override
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    /** {@inheritDoc} */
    @Override
    public List<Employee> findByEmpName(String keyword) {
        return employeeRepository.findByLastNameContainingOrFirstNameContaining(keyword, keyword);
    }

    /** {@inheritDoc} */
    @Override
    public List<Employee> findByDeptNo(Integer deptNo) {
        return employeeRepository.findByDeptNo(deptNo);
    }

    /** {@inheritDoc} */
    @Override
    public Employee findById(Integer empNo) {
        return employeeRepository.findById(empNo).orElse(null);
    }

    /** {@inheritDoc} */
    @Override
    public Employee save(EmployeeForm employeeForm) {
        Employee employee = new Employee();
        employee.setEmpNo(employeeForm.getEmpNo());
        employee.setLastName(employeeForm.getLastName());
        employee.setFirstName(employeeForm.getFirstName());
        employee.setLastKana(employeeForm.getLastKana());
        employee.setFirstKana(employeeForm.getFirstKana());
        employee.setPassword(employeeForm.getPassword());
        employee.setGender(employeeForm.getGender());
        employee.setDeptNo(employeeForm.getDeptNo());

        return employeeRepository.save(employee);
    }

    /** {@inheritDoc} */
    @Override
    public Employee update(EmployeeForm employeeForm) {
        Employee employee = new Employee();
        employee.setEmpNo(employeeForm.getEmpNo());
        employee.setLastName(employeeForm.getLastName());
        employee.setFirstName(employeeForm.getFirstName());
        employee.setLastKana(employeeForm.getLastKana());
        employee.setFirstKana(employeeForm.getFirstKana());
        employee.setPassword(employeeForm.getPassword());
        employee.setGender(employeeForm.getGender());
        employee.setDeptNo(employeeForm.getDeptNo());

        return employeeRepository.save(employee);
    }

    /** {@inheritDoc} */
    @Override
    public void deleteById(Integer empNo) {
        employeeRepository.deleteById(empNo);
    }
}
