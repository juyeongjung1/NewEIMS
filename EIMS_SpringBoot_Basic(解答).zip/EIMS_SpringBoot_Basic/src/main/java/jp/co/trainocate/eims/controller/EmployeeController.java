package jp.co.trainocate.eims.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import jp.co.trainocate.eims.entity.Employee;
import jp.co.trainocate.eims.form.EmployeeForm;
import jp.co.trainocate.eims.service.DepartmentService;
import jp.co.trainocate.eims.service.EmployeeService;

@Controller
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;
    private final DepartmentService departmentService;

    /** トップページを表示する */
    @GetMapping({"/", "/index"})
    public String index() {
        return "index";
    }

    /** 社員一覧を表示する */
    @GetMapping("/employeeList")
    public String showEmployeeList(Model model) {
        model.addAttribute("employees", employeeService.findAll());
        return "employee_list";
    }

    /** 検索画面を表示する */
    @GetMapping("/search")
    public String showSearch(Model model) {
        model.addAttribute("departments", departmentService.findAll());
        return "search";
    }

    /** 社員番号で検索 */
    @GetMapping("/selectByEmpNo")
    public String searchByEmpNo(Integer empNo, Model model) {
        if (empNo == null) {
            model.addAttribute("message", "社員番号を入力してください。");
            model.addAttribute("departments", departmentService.findAll());
            return "search";
        }

        Employee employee = employeeService.findById(empNo);
        if (employee != null) {
            // ヒットした場合は詳細画面を直接表示
            model.addAttribute("employee", employee);
            return "employee_detail";
        }
        // ヒットしない場合は結果画面へ（0件表示用）
        model.addAttribute("employees", new ArrayList<Employee>());
        return "search_result";
    }

    /** 氏名で検索 */
    @GetMapping("/selectByEmpName")
    public String searchByEmpName(String keyword, Model model) {
        // isBlank() は、空文字または空白（半角・全角など）だけの場合に true を返す
        if (keyword == null || keyword.isBlank()) {
            model.addAttribute("message", "社員名を入力してください。");
            model.addAttribute("departments", departmentService.findAll());
            return "search";
        }

        List<Employee> employees = employeeService.findByEmpName(keyword);
        model.addAttribute("employees", employees);
        return "search_result";
    }

    /** 部署番号で検索 */
    @GetMapping("/selectByDeptNo")
    public String searchByDeptNo(Integer deptNo, Model model) {
        if (deptNo == null) {
            model.addAttribute("message", "部署を選択してください。");
            model.addAttribute("departments", departmentService.findAll());
            return "search";
        }

        List<Employee> employees = employeeService.findByDeptNo(deptNo);
        model.addAttribute("employees", employees);
        return "search_result";
    }

    /** 社員詳細を表示する */
    @GetMapping("/detail/{empNo}")
    public String showDetail(@PathVariable("empNo") Integer empNo, Model model) {
        Employee employee = employeeService.findById(empNo);
        model.addAttribute("employee", employee);
        return "employee_detail";
    }

    /** 登録画面を表示する（初回表示・GET） */
    @GetMapping("/input")
    public String showInputPage(EmployeeForm employeeForm, Model model) {
        model.addAttribute("departments", departmentService.findAll());
        return "input";
    }

    /** 確認画面から「修正する」で登録画面へ戻る（POST・入力値を保持） */
    @PostMapping("/input")
    public String backToInputPage(EmployeeForm employeeForm, Model model) {
        model.addAttribute("departments", departmentService.findAll());
        return "input";
    }

    /** 登録内容を確認する */
    @PostMapping("/inputConfirm")
    public String confirmRegistration(@Valid EmployeeForm employeeForm, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("departments", departmentService.findAll());
            return "input";
        }
        // 部署名を表示するために部署情報を取得
        model.addAttribute("department", departmentService.findById(employeeForm.getDeptNo()));
        return "input_confirm";
    }

    /** 新規社員を保存する */
    @PostMapping("/saveEmployee")
    public String saveEmployee(EmployeeForm employeeForm, Model model) {
        Employee employee = employeeService.save(employeeForm);
        model.addAttribute("employee", employee);
        return "input_complete";
    }

    /** 削除確認画面を表示する */
    @GetMapping("/deleteConfirm/{empNo}")
    public String deleteConfirm(@PathVariable("empNo") Integer empNo, Model model) {
        Employee employee = employeeService.findById(empNo);
        if (employee == null) {
            model.addAttribute("employees", new ArrayList<Employee>());
            model.addAttribute("message", "指定された社員情報は存在しないため、削除できません。");
            return "search_result";
        }
        model.addAttribute("employee", employee);
        return "delete_confirm";
    }

    /** 社員を削除する */
    @PostMapping("/deleteEmployee")
    public String deleteEmployee(Integer empNo, Model model) {
        if (empNo == null || employeeService.findById(empNo) == null) {
            model.addAttribute("employees", new ArrayList<Employee>());
            model.addAttribute("message", "指定された社員情報は存在しないため、削除できません。");
            return "search_result";
        }
        employeeService.deleteById(empNo);
        return "delete_complete";
    }

    /** 変更画面を表示する（初回表示・GET：DBから現在の登録内容をフォームにセット） */
    @GetMapping("/changeInput/{empNo}")
    public String changeInput(@PathVariable("empNo") Integer empNo, EmployeeForm employeeForm, Model model) {
        Employee employee = employeeService.findById(empNo);
        employeeForm.setEmpNo(employee.getEmpNo());
        employeeForm.setLastName(employee.getLastName());
        employeeForm.setFirstName(employee.getFirstName());
        employeeForm.setLastKana(employee.getLastKana());
        employeeForm.setFirstKana(employee.getFirstKana());
        employeeForm.setPassword(employee.getPassword());
        employeeForm.setGender(employee.getGender());
        employeeForm.setDeptNo(employee.getDeptNo());

        model.addAttribute("departments", departmentService.findAll());
        return "change";
    }

    /** 確認画面から「修正する」で変更画面へ戻る（POST：DBから取り直さず入力値を保持） */
    @PostMapping("/changeInput/{empNo}")
    public String backToChangeInput(@PathVariable("empNo") Integer empNo, EmployeeForm employeeForm, Model model) {
        model.addAttribute("departments", departmentService.findAll());
        return "change";
    }

    /** 変更内容を確認する */
    @PostMapping("/changeConfirm")
    public String changeConfirm(@Valid EmployeeForm employeeForm, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("departments", departmentService.findAll());
            return "change";
        }
        model.addAttribute("department", departmentService.findById(employeeForm.getDeptNo()));
        return "change_confirm";
    }

    /** 社員情報を更新する */
    @PostMapping("/changeEmployee")
    public String changeEmployee(EmployeeForm employeeForm, Model model) {
        Employee employee = employeeService.update(employeeForm);
        model.addAttribute("employee", employee);
        return "change_complete";
    }
}
