package jp.co.trainocate.eims.service;

/**
 * 従業員に関するビジネスロジックを定義するサービスインターフェース。
 */

import java.util.List;

import jp.co.trainocate.eims.entity.Employee;
import jp.co.trainocate.eims.form.EmployeeForm;

public interface EmployeeService {
    /**
     * 社員テーブルを全件取得します。
     * @return 社員エンティティのリスト
     */
    List<Employee> findAll();

    /**
     * 氏または名にキーワードを含む社員を検索します。
     * @param keyword 検索キーワード
     * @return 該当する社員エンティティのリスト
     */
    List<Employee> findByEmpName(String keyword);

    /**
     * 部署番号を基に従業員を検索します。
     * @param deptNo 部署番号
     * @return 社員のリスト
     */
    List<Employee> findByDeptNo(Integer deptNo);

    /**
     * 社員番号を指定して 1 件取得します（詳細画面用）。
     * @param empNo 社員番号
     * @return 従業員エンティティ
     */
    Employee findById(Integer empNo);

    /**
     * 社員情報を保存します。
     * @param employeeForm 入力フォーム
     * @return 保存後のエンティティ
     */
    Employee save(EmployeeForm employeeForm);

    /**
     * 社員情報を更新します。
     * @param employeeForm 入力フォーム
     * @return 更新後のエンティティ
     */
    Employee update(EmployeeForm employeeForm);

    /**
     * 社員番号を指定して 1 件削除します。
     * @param empNo 社員番号
     */
    void deleteById(Integer empNo);

}
