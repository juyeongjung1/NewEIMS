package jp.co.trainocate.eims.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.trainocate.eims.entity.Department;
import jp.co.trainocate.eims.repository.DepartmentRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository departmentRepository;

    /** {@inheritDoc} */
    @Override
    public List<Department> findAll() {
        return departmentRepository.findAll();
    }

    /** {@inheritDoc} */
    @Override
    public Department findById(Integer deptNo) {
        return departmentRepository.findById(deptNo).orElse(null);
    }
}
